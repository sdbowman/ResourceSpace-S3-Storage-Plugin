<?php
/** s3_storage Plugin Simple Storage Service (S3) Functions File
* This file contains the required functions for the s3_storage plugin.
*
* Once the AWS PHP v3.158.6 SDK is loaded via the class autoloader file, the function $s3_storage_setup defines the
* provider endpoint URL and SDK shared configuration parameters for setting up S3 and AWS CloudWatch clients in other
* functions, and then a new SDK class is defined.  The remainder of the s3_storage_functions.php file contains the S3
* storage specific functions.
*
* Future versions of the SDK (https://docs.aws.amazon.com/sdk-for-php/v3/developer-guide/getting-started_installation.
* html#installing-by-using-the-zip-file) can be used by saving the specific SDK to a new ../plugins/s3_storage/lib
* folder, deleting the older SDK folder, and changing Line 18 below to the new folder name.  Should a new SDK use a
* new S3 and /or CloudWatch API version, that can be changed in the 'Set the AWS PHP S3 API version' section of
* ../plugins/config/config.php.
*/

// Load the AWS PHP SDK Version 3 class autoloader and supporting modules.
require dirname(__FILE__) . "/../lib/aws_php_sdk_3.173.22/aws-autoloader.php";
use Aws\S3\S3Client;
use Aws\S3\S3ClientInterface;
use Aws\ResultInterface;
use Aws\CloudWatch\CloudWatchClient;
use Aws\Exception\AwsException;
use Aws\S3\Exception\S3Exception;
use Aws\S3\ObjectUploader;
use Aws\S3\ObjectCopier;

include_once dirname(__FILE__) . "/../../../include/db.php";
include_once dirname(__FILE__) . "/../../../include/image_processing.php";


// Collection download ZIP file streaming.
function s3_zip_download($collection_data, $results, $available_sizes, $collection_folders = false, $zip_remove_resource = false)
    {
    require dirname(__FILE__) . "/../lib/zipstream-php/vendor/autoload.php";

    global $s3_storage_collection_prefix, $zipped_collection_textfile, $include_csv_file, $size, $progress_file,  $s3_storage_zip_wordwrap, $s3_zip_deflatelevel, $s3_zip_largefile, $s3_zip_largefilecompress, $s3_zip_separator_end, $usercollection;

    $text_filename = 'Text_MetadataExport.txt'; # Default text metadata export filename.
    $csv_filename = 'CSV_MetadataExport.csv'; # Default CSV metadata export filename.
    $original_metadata_field = 51; # Original filename metadata field ID.

    // Return if the results array does not contain any resources.
    $results_count = count($results);
    debug("S3_ZIP Results Count: {$results_count}");
    if($results_count == 0)
        {
        return false;
        }

    // If a collection download, get the collection info, its resources, and a folder and ZIP file name.
    if(is_array($collection_data) && !$collection_folders)
        {
        $folder = s3_filefolder_name($collection_data['name']);
        $zip_file = trim("{$s3_storage_collection_prefix}_{$folder}.zip", "_ ");
        }
    // If a download of various resources in multiple collections.
    elseif(is_array($collection_data) && $collection_folders)
        {
        $zip_file = trim("{$s3_storage_collection_prefix}_FileDownload.zip", "_ ");
        $size = 'original';
        }
    else # ERROR.
        {
        return false;
        }

    // Get a temporary s3_temp folder to store resources downloaded from a S3 bucket for metadata processing.
    $user_session = get_rs_session_id(true);
    $s3_temp = s3_create_temp($user_session);

    // Create the metadata text file header rows.
    if($zipped_collection_textfile)
        {
        $s3_zip_text = s3_zip_textheader($collection_data, $s3_storage_zip_wordwrap, $zip_file, $collection_folders, $text_filename);
        }

    // Set the streaming ZIP file options.
    $zip_filesize = 0;
    $zip_options = new ZipStream\Option\Archive();
    $zip_options->setSendHttpHeaders(true);
    $zip_options->setDeflateLevel($s3_zip_deflatelevel);
    $zip_options->setLargeFileSize($s3_zip_largefile);
    if($s3_zip_largefilecompress)
        {
        $zip_options->setLargeFileMethod(ZipStream\Option\Method::DEFLATE()); # Compress large files.
        }
    else
        {
        $zip_options->setLargeFileMethod(ZipStream\Option\Method::STORE()); # Do not compress large files.
        }
    $zip_options->setContentDisposition('attachment');
    $zip_options->setContentType('application/x-zip');

    // Create a new ZipStream object.
    $zipstream = new ZipStream\ZipStream($zip_file, $zip_options);

    // Create a metadata CSV file for the download and add to the ZIP stream.
    if($include_csv_file == 'yes' || $collection_folders)
        {
        $csv_file = "{$s3_temp}{$csv_filename}";
        $csv_file = s3_zip_csv(array_column($results, 'ref'), $csv_file);
        if($csv_file != false)
            {
            $s3_zip_csv = pathinfo($csv_file, PATHINFO_BASENAME);
            $zipstream->addFileFromPath($s3_zip_csv, $csv_file);

            // Increment the total ZIP filesize and delete the local CSV file.
            $zip_filesize += filesize_unlimited($csv_file);
            unlink($csv_file);

            // Add the CSV info to the metadata text file.
            if($zipped_collection_textfile)
                {
                $s3_zip_text .= 'Comma-Separated Value (CSV) Metadata File' . "\r\n";
                $s3_zip_text .= "  {$s3_zip_csv}\r\n\r\n";
                }
            }
        }

    // Create an array of the resources/files to download and add to the streaming ZIP file.
    $download_array = s3_download_array($results, $available_sizes, $size, $results_count);
    $download_count = count($download_array);
    unset($results);

    // Loop through the collection resources and create the streaming ZIP file.
    $zip_file_counter = 0;
    for($n = 0; $n < $download_count; $n++)
        {
        // Get the resource Ref ID and its basic metadata.
        $ref = $download_array[$n]['ref'];
        $resource_data = get_resource_data($ref);

        if($download_array[$n]['size'] == 'original' || $download_array[$n]['size'] == '')
            {
            // Download the original resource from a S3 bucket to the ../filestore/tmp/s3_temp folder.
            try
                {
                // Determine the filestore file info and local tmpfile name.
                $size = 'original';
                $org_filename = sql_query("SELECT value FROM resource_data WHERE resource_type_field = '" . escape_check($original_metadata_field) . "' AND resource = '" . escape_check($ref) . "'");
                $result['fs_tmpfile'] = "{$s3_temp}{$org_filename[0]['value']}";

                // Determine the object path, check if it exists, and download the original file from a S3 bucket.
                $s3_object = s3_object_path($download_array[$n]['filepath'], false);
                $s3_result = s3_object_exists($s3_object);
                if($s3_result)
                    {
                    s3_object_download($s3_object, $result['fs_tmpfile']);
                    $result['status'] = true;
                    chmod($result['fs_tmpfile'], 0777);
                    }
                else
                    {
                    $result['status'] = false;
                    debug('ERROR S3_ZIP_DOWNLOAD: S3 Object Does Not Exist.');
                    }
                }
            catch(Exception $e) # ERROR.
                {
                $result['status'] = false;
                debug('ERROR S3_ZIP_DOWNLOAD S3: ' . $e->getMessage());
                }

            //debug('S3_ZIP_DOWNLOAD Result: ' . print_r($result, true));
            }
        // Not downloading a resource original, so use the filestore version/size.
        else
            {
            $result['fs_tmpfile'] = $results[$n]['filepath'];
            }

        // Write the resource metadata to the downloaded tmpfile.
        $metadata_temp = write_metadata($result['fs_tmpfile'], $ref);
        if($result['status'] == true && is_file($result['fs_tmpfile']))
            {
            unlink($result['fs_tmpfile']);
            }
        elseif(!is_file($metadata_temp)) # ERROR: Resource file not available, skip.
            {
            continue;
            }
        else # ERROR: Resource file not available, skip.
            {
            continue;
            }

        // Add the original tmpfile to the ZIP stream and output.
        debug("S3_ZIP_DOWNLOAD, Adding File to ZIP Stream: {$metadata_temp}");
        $s3_zip_resources[] = $ref;
        $ref_data = get_resource_data($ref);
        $file = s3_zipdownload_filename($result['fs_tmpfile'], $ref);

        // Create sub-folders for each collection a resource is in.
        if($collection_folders)
            {
            $ref_collections = get_themes_by_resource($ref);
            debug('S3_ZIP_DOWNLOAD Collections: ' . print_r($ref_collections, true));
            foreach($ref_collections as $ref_collection)
                {
                $folder = s3_filefolder_name($ref_collection['name']);
                $zipstream->addFileFromPath($folder . DIRECTORY_SEPARATOR . $file, $metadata_temp);

                // Increment the total ZIP filesize.
                $zip_filesize += $ref_data['file_size'];
                }
            }
        // For collection downloads, just add the file.
        else
            {
            $folder = s3_filefolder_name($collection_data['name']);
            $zipstream->addFileFromPath($folder . DIRECTORY_SEPARATOR . $file, $metadata_temp);
            $ref_collections[] = $collection_data['ref'];

            // Increment the total ZIP filesize.
            $zip_filesize += $ref_data['file_size'];
            }

        // Delete the temp file and remove the resource from the user collection.
        unlink($metadata_temp);
        if($zip_remove_resource)
            {
            remove_resource_from_collection($ref, $usercollection);
            }

        // Update the text file.
        if($zipped_collection_textfile)
            {
            $s3_zip_text .= s3_zip_textrow($ref, $resource_data, $ref_collections, $file, $s3_storage_zip_wordwrap, $size);
            }

        ++$zip_file_counter;
        unset($ref, $ref_data, $resource_data, $ref_collections, $file);
        }

    // Add the metadata text file for the download to the ZIP stream and delete the local tmpfile.
    if($zipped_collection_textfile)
        {
        $text_file = s3_zip_textfile($s3_zip_text, "{$s3_temp}{$text_filename}", $zip_filesize, $s3_zip_resources, $s3_storage_zip_wordwrap, $zip_file_counter, $download_count, $collection_folders);
        unset($s3_zip_text, $zip_filesize, $s3_zip_resources);

        if($text_file != false)
            {
            $zipstream->addFileFromPath($text_filename, $text_file);
            unlink($text_file);
            }
        }

    // Complete the streamed ZIP file.
    $zipstream->finish();

    if($zip_remove_resource)
        {
        refresh_collection_frame($usercollection);
        }

    // Delete the temp ../filestore/tmp/s3_temp/session_ID folder.
    if(is_dir($s3_temp))
        {
        rcRmdir($s3_temp);
        }
debug("S3 ZIP UC: {$usercollection}");
refresh_collection_frame($usercollection);
    //exit();
    }


// Function to create an array of files to download for streaming ZIP file.
function s3_download_array($result, $available_sizes, $size, $result_count)
    {
    global $restricted_full_download, $original_metadata_field;

    // Build a list of files to download.
    $counter = 0;
    for($n = 0; $n < $result_count; $n++)
        {
        $ref = $result[$n]['ref'];

        // Execute override for every resource.
        resource_type_config_override($result[$n]['resource_type'], false);

        // Load the resource access level.
        $access = get_resource_access($ref);

        // Only download resources with proper access level.
        if($access == 0 || $access == 1)
            {
            if($size == 'largest')
                {
                foreach($available_sizes as $available_size => $resources)
                    {
                    if(in_array($ref, $resources))
                        {
                        // Has access to the original so no need to check previews.
                        $usesize = $available_size;
                        if($available_size == 'original')
                            {
                            $usesize = '';
                            break;
                            }
                        }
                    }
                }
            else
                {
                $usesize = ($size == 'original') ? '' : $size;
                }

            // Determine whether the target file exists.
            if($usesize = 'original' or $size == 'largest')
                {
                $target_exists = true;
                $usesize = '';
                }
            else
                {
                $p = get_resource_path($ref, true, '', false, $result[$n]['file_extension']);
                $target_exists = file_exists($p);
                }

            // Build the resources to download array.
            if((($target_exists && $access == 0) || ($target_exists && $access == 1 && (image_size_restricted_access($size) || ($usesize == '' && $restricted_full_download)))) && resource_download_allowed($ref, $usesize, $result[$n]['resource_type']))
                {
                $resources[$counter]['ref'] = $ref;
                $resources[$counter]['size'] = $usesize;

                // Determine the resource original filename.
                $file = sql_query("SELECT value FROM resource_data WHERE resource = '" . escape_check($ref) . "' AND resource_type_field = '" . escape_check($original_metadata_field) . "'");
                $resources[$counter]['filename'] = s3_zipdownload_filename($file[0]['value'], $ref, $separator = '_');

                // Determine the resource original file extension and filestore resource path.
                $file_extension = get_extension($result[$n], $usesize);
                $resources[$counter]['filepath'] = get_resource_path($ref, true, $usesize, false, $file_extension);

                ++$counter;
                }
            }
        else # Not the proper access level.
            {
            continue;
            }
        }

    return $resources;
    }


// Function to create the streamed ZIP text metadata file header rows.
function s3_zip_textheader($collection_data, $zip_wordwrap, $zip_file, $collection_folders, $text_filename)
    {
    global $lang, $baseurl, $applicationname;

    // Header text.
    $s3_zip_text = wordwrap(strtoupper("{$lang['s3_storage_cdownload_header']} {$zip_file} {$lang['archive']} {$lang['file']}") . "\r\n\r\n", $zip_wordwrap, "\r\n ");

    $s3_zip_text .= wordwrap("{$lang['created']}/{$lang['downloaded']} {$lang['on_date']} " . nicedate(date("Y-m-d H:i:s"), true, true) . " {$lang['L_from']} {$applicationname} ({$baseurl}).\r\n\r\n", $zip_wordwrap, "\r\n ");

    // Collection fields.
    $s3_zip_text .= "{$lang['s3_zip_collection_title']}\r\n\r\n";
    if(!array_key_exists('name', $collection_data))
        {
        foreach($collection_data as $collection)
            {
            $coll_data = sql_query("SELECT ref,name,keywords,description FROM collection WHERE ref = '" . escape_check($collection) . "'");
            $s3_zip_text .= s3_zip_collectionrow($coll_data[0], $zip_wordwrap);
            }
        }
    else
        {
        $s3_zip_text .= s3_zip_collectionrow($collection_data, $zip_wordwrap);
        }

    $s3_zip_text .= "{$lang['s3_storage_cdownload_contents']}\r\n\r\n";

    $s3_zip_text .= "{$lang['s3_storage_download_textfile']}\r\n";
    $s3_zip_text .= "  {$text_filename}\r\n\r\n";

    debug('S3_ZIP_TEXTHEADER Results: ' . print_r($s3_zip_text, true));
    return $s3_zip_text;
    }


// Function to create the collection detail ZIP text metadata file header rows.
function s3_zip_collectionrow($collection_data, $zip_wordwrap)
    {
    global $lang, $baseurl;

    $s3_zip_text = wordwrap("{$lang['collection']}: {$collection_data['name']}\r\n", $zip_wordwrap, "\r\n ");

    if($collection_data['description'] != '')
        {
        $s3_zip_text .= wordwrap("  {$lang['description']}: {$collection_data['description']}\r\n", $zip_wordwrap, "\r\n    ");
        }

    if($collection_data['keywords'] != '')
        {
        $s3_zip_text .= wordwrap("  {$lang['fieldtitle-keywords']}: {$collection_data['keywords']}\r\n", $zip_wordwrap, "\r\n    ");
        }

    $s3_zip_text .= wordwrap("  {$lang['s3_zip_coll_url']}: {$baseurl}/pages/search.php?search=!collection{$collection_data['ref']}\r\n\r\n", $zip_wordwrap, "\r\n    " , true);

    return $s3_zip_text;
    }


// Function to create the resource text rows in the ZIP text metadata file.
function s3_zip_textrow($ref, $resource_data, $collections, $filename, $zip_wordwrap, $sizetext)
    {
    global $lang, $zipped_collection_textfile, $k, $baseurl, $s3_zip_separator_end;

    if($zipped_collection_textfile)
        {
        if($k === '')
            {
            $fields = get_resource_field_data($ref);
            }
        else # External shares should take into account fields that are not meant to show in that case.
            {
            $fields = get_resource_field_data($ref, false, true, null, true);
            }

        $fields_count = count($fields);
        if($fields_count > 0)
            {
            $s3_zip_text = "{$lang['file']}: {$filename} (" . ucwords(($sizetext == '' ? '' : $sizetext) . " {$lang['size']}") . ")\r\n";
            $s3_zip_text .= s3_zip_separator($zip_wordwrap, '-') . "\r\n";

            $resource_type = sql_query("SELECT name FROM resource_type WHERE ref = '" . escape_check($resource_data['resource_type']) . "'");
            $s3_zip_text .= "{$lang['resourceid']} {$lang['lc_and']} {$lang["type"]}: {$ref} ({$resource_type[0]['name']})\r\n";

            // Metadata fields.
            for($i = 0; $i < $fields_count; $i++)
                {
                $value = $fields[$i]['value'];
                $title = ucwords(str_replace('Keywords - ', '', $fields[$i]['title']));
                if((trim($value) != '') && (trim($value) != ','))
                    {
                    $s3_zip_text .= wordwrap("  {$title}: " . i18n_get_translated($value) . "\r\n", $zip_wordwrap, "\r\n    ");
                    }
                }

            // Spatial location.
            if($resource_data['geo_lat'] != null && $resource_data['geo_long'] != null && $resource_data['geo_lat'] >= -90 && $resource_data['geo_lat'] <= 90 && $resource_data['geo_long'] >= -180 && $resource_data['geo_long'] <= 180)
                {
                $s3_zip_text .= wordwrap("  Latitude / Longitude: {$resource_data['geo_lat']}, {$resource_data['geo_long']} {$lang['s3_zip_degrees']}\r\n", $zip_wordwrap, "\r\n    ");
                }

            // File size.
            $s3_zip_text .= wordwrap('  ' . ucwords($lang['fieldtitle-file_size']) . ': ' . str_replace('&nbsp;', ' ', formatfilesize($resource_data['file_size'])) . "\r\n", $zip_wordwrap, "\r\n    ");

            // View page URL.
            $s3_zip_text .= wordwrap("  {$lang['s3_zip_url']}: {$baseurl}/pages/view.php?ref={$ref}\r\n", $zip_wordwrap, "\r\n    ", true);

            // Collection data.
            foreach($collections as $collection)
                {

                // Collection name.
                if(is_array($collection))
                    {
                    $s3_zip_text .= wordwrap("{$lang['s3_storage_download_contained']}: {$collection['name']}\r\n", $zip_wordwrap, "\r\n  ");
                    $collection = $collection['ref'];
                    }
                else
                    {
                    $collection_name = sql_query("SELECT name FROM collection WHERE ref = '" . escape_check($collection) . "'");
                    $s3_zip_text .= wordwrap("{$lang['s3_storage_download_contained']}: {$collection_name[0]['name']}\r\n", $zip_wordwrap, "\r\n  ");
                    }

                // Collection comment and rating.
                $comment_data = get_collection_resource_comment($ref, $collection);
                if(trim($comment_data['comment']) != '')
                    {
                    $s3_zip_text .= wordwrap("  {$lang['comment']}: {$comment_data['comment']}\r\n", $zip_wordwrap, "\r\n    ");
                    }
                if(trim($comment_data['rating']) != '')
                    {
                    $s3_zip_text .= wordwrap("  {$lang['rating']}: {$comment_data['rating']}\r\n", $zip_wordwrap, "\r\n    ");
                    }
                }

            if($s3_zip_separator_end)
                {
                $s3_zip_text .= s3_zip_separator($zip_wordwrap, '-') . "\r\n";
                }

            $s3_zip_text .= "\r\n";
            }
        }

    debug('S3_ZIP_TEXT Result: ' . print_r($s3_zip_text, true));
    return $s3_zip_text;
    }


// Function to create the ZIP metadata text separator rows.
function s3_zip_separator($wordwrap, $separator)
    {
    $result = '';
    for($i = 0; $i < $wordwrap; $i++)
        {
        $result .= $separator;
        }

    return $result;
    }


// Function to finalize the ZIP metadata text file.
function s3_zip_textfile($s3_zip_text, $text_file, $zip_filesize, $s3_zip_resources, $zip_wordwrap, $zip_file_counter, $zip_download_count, $zip_collection_folders)
    {
    global $lang, $zipped_collection_textfile, $available_sizes, $subbed_original_resources, $result, $size;

    // ZIP Archive Summary section.
    if($zipped_collection_textfile)
        {
        $s3_zip_text .= $lang['s3_storage_download_summary'] . "\r\n";

        // Total files row.
        $qty_sizes = $zip_file_counter;
        $qty_total = $zip_download_count;

        $s3_zip_text .= "  {$lang['s3_storage_download_note']} {$qty_sizes} {$lang['of']} {$qty_total} ";
        switch($qty_total)
            {
            case 0:
                $s3_zip_text .= "{$lang['resource-0']} ";
                break;
            case 1:
                $s3_zip_text .= "{$lang['resource-1']} ";
                break;
            default:
                $s3_zip_text .= "{$lang['resource-2']} ";
                break;
            }

        switch($qty_sizes)
            {
            case 0:
                $s3_zip_text .= "{$lang['were_available-0']} ";
                break;
            case 1:
                $s3_zip_text .= "{$lang['were_available-1']} ";
                break;
            default:
                $s3_zip_text .= "{$lang['were_available-2']} ";
                break;
            }

        $s3_zip_complete = '.';
        if($qty_sizes == $qty_total)
            {
            $s3_zip_complete = " ({$lang["requeststatus2"]}).";
            }
        $s3_zip_text .= wordwrap("{$lang['s3_zip_archive']}{$s3_zip_complete}\r\n", $zip_wordwrap, "\r\n    ");

        // Missing files row.
        if($qty_sizes != $qty_total)
            {
            $zip_missing = $qty_total - $qty_sizes;
            $s3_zip_text .= wordwrap("{$lang['s3_zip_missing_files']}: {$zip_missing}\r\n", $zip_wordwrap, "\r\n    ");
            }

        // Total file size row.
        $s3_zip_text .= "  {$lang['s3_storage_download_totalsize']}" . str_replace('&nbsp;', ' ', formatfilesize($zip_filesize + strlen($s3_zip_text))) . "\r\n";

        // Substituted or missing resources rows.
        if(!$zip_collection_folders)
            {
            foreach($result as $resource)
                {
                if(in_array($resource['ref'], $subbed_original_resources))
                    {
                    $s3_zip_text .= "  {$lang['didnotinclude']}: {$resource['ref']}";
                    $s3_zip_text .= " ({$lang['substituted_original']})\r\n";
                    }
                elseif(!in_array($resource['ref'], $s3_zip_resources))
                    {
                    $s3_zip_text .= "  {$lang['didnotinclude']}: {$resource['ref']}\r\n";
                    }
                }
            }

        $s3_zip_text .= "\r\n";

        // Create the metadata text file in the ../filestore/tmp/s3_temp folder.
        $fh = fopen($text_file, 'w') or die($lang['s3_zip_texterror']);
        fwrite($fh, $s3_zip_text);
        fclose($fh);

        // Return the metadata text file path.
        if(is_readable($text_file))
            {
            return $text_file;
            }
        }

    return false;
    }


// Function to create a metadata CSV file for the ZIP resources.
function s3_zip_csv($resources, $csv_file)
    {
    // Create the metadata CSV file, add it to the root of the ZIP structure, and delete the CSV file.
    s3_zip_generate_csv($resources, '', '', $csv_file);
    if(is_readable($csv_file))
        {
        debug("S3_ZIP_CSV, Created: {$csv_file}");
        chmod($csv_file, 0777);
        return $csv_file;
        }

    debug('ERROR S3_ZIP_CSV: File not created.');
    return false;
    }


/**
* Generates the CSV content of the metadata for resources passed in the array.
*
* @param    array   $resources  Array of resource IDs.
* @return   string
*/
function s3_zip_generate_csv(array $resources, $personal = false, $alldata = false, $outputfile = '')
    {
    global $lang, $csv_export_add_original_size_url_column, $file_checksums, $k, $scramble_key, $get_resource_data_cache, $disable_geocoding, $show_contributed_by, $s3_storage_show_status;

    // Write the CSV to a disk to avoid memory issues with large result sets.
    $tempcsv = trim($outputfile) != '' ? $outputfile : get_temp_dir() . '/csv_export_' . uniqid() . '.csv';

    $resource_batch_size = 2000;
    $csv_field_headers = array();
    $csv_options = array('csvexport' => true, 'personal' => $personal, 'alldata' => $alldata);
    $allfields = get_resource_type_fields('', 'order_by', 'asc');
    $cache_location = get_query_cache_location();
    $cache_data = array();
    $restypearr = get_resource_types();
    $resource_types = array();

    // Sort into array with IDs as keys.
    foreach($restypearr as $restype)
        {
        $resource_types[$restype['ref']] = $restype;
        }

    // Break resources up into smaller arrays to avoid hitting memory limits.
    $resource_batches = array_chunk($resources, $resource_batch_size);
    $resource_batches_count = count($resource_batches);

    $csv_field_headers['resource_type'] = $lang['resourcetype'];

    // Add Status column?
    if($s3_storage_show_status)
        {
        $csv_field_headers['status'] = $lang['status'];
        }

    // Add Contributed By column?
    if($show_contributed_by)
        {
        $csv_field_headers['created_by'] = $lang['contributedby'];
        }

    // Add File Checksum column?
    if($file_checksums && $alldata)
        {
        $csv_field_headers['file_checksum'] = $lang['filechecksum'];
        }

    // Add Original Size URL column?
    if($csv_export_add_original_size_url_column)
        {
        $csv_field_headers['original_link'] = $lang['collection_download_original'];
        }

    // Add resource spatial location data?
    if(!$disable_geocoding)
        {
        $csv_field_headers['geo_lat'] = $lang['latitude'];
        $csv_field_headers['geo_long'] = $lang['longitude'];
        }

    // Array to store fields that have data, if no data we will not include it.
    $include_fields = array();

    for($n = 0; $n < $resource_batches_count; $n++)
        {
        $resources_fields_data = array();
        $fullresdata = get_resource_field_data_batch($resource_batches[$n], true, $k != '', true, $csv_options);

        // Get data for all resources
        $resource_data_array = get_resource_data_batch($resource_batches[$n]);
        foreach($resource_batches[$n] as $resource)
            {
            $resdata = isset($resource_data_array[$resource]) ? $resource_data_array[$resource] : false;
            if(!$resdata || checkperm("T{$resdata["resource_type"]}"))
                {
                continue;
                }

            // Add resource type.
            $restype = get_resource_type_name($resdata['resource_type']);
            $resources_fields_data[$resource]['resource_type'] = $restype;

            // Add resource status.
            if($s3_storage_show_status)
                {
                $resources_fields_data[$resource]['status'] = $lang["status{$resource_data_array[$resource]['archive']}"] ?? $lang['unknown'];
                }

            // Add contributor.
            $udata = get_user($resdata['created_by']);
            if($udata !== false)
                {
                $resources_fields_data[$resource]['created_by'] = (trim($udata['fullname']) != '' ? $udata['fullname'] : $udata['username']);
                }

            if($alldata && $file_checksums)
                {
                $resources_fields_data[$resource]['file_checksum'] = $resdata['file_checksum'];
                }

            foreach($allfields as $restypefield)
                {
                if(metadata_field_view_access($restypefield['ref']) && (!$personal || $restypefield['personal_data'])
                    && ($alldata || $restypefield['include_in_csv_export'])
                    && !(checkperm("T{$restypefield['resource_type']}"))
                    && ($restypefield['resource_type'] == $resdata['resource_type']
                    || ($restypefield['resource_type'] == 0 && (bool)$resource_types[$resdata['resource_type']]['inherit_global_fields'])
                    || ($restypefield['resource_type'] == 999 && $resdata['archive'] == 2)))
                    {
                    if(!isset($csv_field_headers[$restypefield['ref']]))
                        {
                        $csv_field_headers[$restypefield['ref']] = $restypefield['title'];
                        }

                    // Check if the resource has a value for this field in the data retrieved.
                    if(isset($fullresdata[$resource]))
                        {
                        $resdataidx = array_search($restypefield['ref'], array_column($fullresdata[$resource], 'ref'));
                        $fieldvalue = ($resdataidx !== false) ? $fullresdata[$resource][$resdataidx]['value'] : '';
                        $resources_fields_data[$resource][$restypefield['ref']] = $fieldvalue;
                        }
                    }
                }

            // Provide the original URL only if we have access to the resource or the user group does not have restricted access to the original size.
            $access = get_resource_access($resdata);
            if(0 != $access || checkperm("T{$resdata['resource_type']}_"))
                {
                continue;
                }

            if($csv_export_add_original_size_url_column)
                {
                $original_link = get_resource_path($resource, false, '', false, $resdata['file_extension'], -1, 1, false, '', -1, false);
                $resources_fields_data[$resource]['original_link'] = $original_link;
                }

            // Resource spatial location data.
            if(!$disable_geocoding)
                {
                $resources_fields_data[$resource]['geo_lat'] = $resdata['geo_lat'];
                $resources_fields_data[$resource]['geo_long'] = $resdata['geo_long'];
                }
            }

        if(count($resources_fields_data) > 0)
            {
            // Save data to temporary files in order to prevent memory limits being reached.
            $tempjson = json_encode($resources_fields_data);
            $cache_data[$n] = "{$cache_location}/csv_export_" . md5("{$scramble_key}{$tempjson}") . '.json'; # Scrambled path to cache.
            file_put_contents($cache_data[$n], $tempjson);
            $tempjson = null;
            }
        }

    // Header
    $csv_field_headers = array_unique($csv_field_headers);
    array_walk($csv_field_headers, "s3_csv_header_ucwords");
    $header = "\"{$lang['resourceid']}\",\"" . implode('","', $csv_field_headers) . "\"\n";
    file_put_contents($tempcsv, $header);

    // Results
    for($n = 0; $n < $resource_batches_count; $n++)
        {
        $filedata = '';
        $resources_fields_data = array();
        if(file_exists($cache_data[$n]))
            {
            $resources_fields_data = json_decode(file_get_contents($cache_data[$n]), true);
            }
        if(is_null($resources_fields_data))
            {
            $resources_fields_data = array();
            }

        foreach($resources_fields_data as $resource_id => $resource_fields)
            {
            // First column will always be Resource ID.
            $csv_row = "{$resource_id},";

            // Field values.
            foreach($csv_field_headers as $column_header => $column_header_title)
                {
                if(!array_key_exists($column_header, $resource_fields))
                    {
                    $csv_row .= '"",';
                    continue;
                    }

                foreach($resource_fields as $field_name => $field_value)
                    {
                    if($column_header == $field_name)
                        {
                        $csv_row .= '"' . str_replace(array("\""), array("\"\""), i18n_get_translated($field_value)) . '",';
                        }
                    }
                }

            $csv_row = rtrim($csv_row, ',');
            $csv_row .= "\n";
            $filedata .= $csv_row;
            }

        // Add this data to the file and delete disk copy of array.
        file_put_contents($tempcsv, $filedata, FILE_APPEND);
        if(file_exists($cache_data[$n]))
            {
            unlink($cache_data[$n]);
            }
        }

    // Data has been saved to file, just return.
    if($outputfile != '')
        {
        return true;
        }

    // Echo the data for immediate download.
    echo file_get_contents($tempcsv);
    }


// Function to Upper Case each CSV header value.
function s3_csv_header_ucwords(&$value)
    {
    $value = ucwords($value);
    }


// Function to create download filenames.
function s3_zipdownload_filename($file, $ref = '', $separator = '_')
    {
    global $prefix_filename_string, $prefix_resource_id_to_filename;

    $result = "{$prefix_filename_string}{$separator}";
    if($prefix_filename_string != '' && $prefix_resource_id_to_filename && is_numeric($ref))
        {
        $result = "{$prefix_filename_string}{$ref}{$separator}";
        }

    return trim($result . pathinfo($file, PATHINFO_BASENAME));
    }


// Function to create OS-compliant file/folder names.
function s3_filefolder_name($name)
    {
    return preg_replace('/[^a-zA-Z0-9_.-]/', '', str_replace(' ', '_', $name));
    }


/**
* Function to check that the required ResourceSpace S3 storage parameters are set fromm the plugin configuration page.
* Parameters $s3_storage_enable, $s3_storage_provider, $s3_storage_key, $s3_storage_secret, $s3_storage_region,
* $s3_storage_bucket, $s3_storage_class, and $s3_storage_stats must be set.
*
* @return boolean   TRUE on success; otherwise, FALSE.
*/
function s3_check_parameters()
    {
    global $storagedir, $s3_storage_enable, $s3_storage_provider, $s3_storage_key, $s3_storage_secret, $s3_storage_region, $s3_storage_bucket, $s3_storage_class, $s3_storage_stats;

    if(isset($storagedir) && isset($s3_storage_enable) && $s3_storage_enable && isset($s3_storage_provider) && isset($s3_storage_key) && isset($s3_storage_secret) && isset($s3_storage_region) && isset($s3_storage_bucket) && isset($s3_storage_class) && isset($s3_storage_stats))
        {
        debug('S3_CHECK_PARAMETERS Result: ' . boolean_convert(true, 'ok'));
        return true;
        }

    debug('ERROR S3_CHECK_PARAMETERS Result: ' . boolean_convert(false, 'ok'));
    return false;
    }


/**
* Function to setup the AWS PHP SDK and the S3 storage environment.  Call before setting up a SDK client.
*
* @return array     Configuration parameters AWS SDK class for setting up SDK clients; otherwise, FALSE.
*/
function s3_storage_setup()
    {
    global $s3_storage_provider, $s3_storage_endpoint, $s3_storage_region, $s3_storage_key, $s3_storage_secret, $s3_storage_stats, $s3_api_version, $cw_api_version, $s3_storage_setup_debug, $s3_storage_path_endpoint;

    try
        {
        // Define the AWS S3 endpoint URL.
        if($s3_storage_provider == 'AWS')
            {
            $s3_storage_endpoint = "https://s3.{$s3_storage_region}.amazonaws.com";
            }

        // Set the AWS PHP SDK shared client configuration.
        if($s3_storage_path_endpoint != null && $s3_storage_provider != 'AWS')
            {
            $s3_storage_path_endpoint = boolean_convert($s3_storage_path_endpoint, 'true');
            $sdk_shared_config = [
                'region' => $s3_storage_region,
                'credentials' => [
                    'key' => $s3_storage_key,
                    'secret' => $s3_storage_secret
                    ],
                'stats' => $s3_storage_stats,
                'S3' => [
                    'version' => $s3_api_version,
                    'endpoint' => $s3_storage_endpoint,
                    'use_path_style_endpoint' => $s3_storage_path_endpoint
                    ],
                'CloudWatch' => [
                    'version' => $cw_api_version
                    ]
                ];
            }
        else
            {
            $sdk_shared_config = [
                'region' => $s3_storage_region,
                'credentials' => [
                    'key' => $s3_storage_key,
                    'secret' => $s3_storage_secret
                    ],
                'stats' => $s3_storage_stats,
                'S3' => [
                    'version' => $s3_api_version,
                    'endpoint' => $s3_storage_endpoint,
                    ],
                'CloudWatch' => [
                    'version' => $cw_api_version
                    ]
                ];
            }

        // Create a configuration parameters AWS SDK class to share across multiple clients.
        $aws_sdk = new Aws\Sdk($sdk_shared_config);
        if($s3_storage_setup_debug)
            {
            debug('S3_STORAGE_SETUP Result: ' . print_r($aws_sdk, true));
            }

        return $aws_sdk;
        }
    catch(S3Exception $e)
        {
        debug('ERROR S3_STORAGE_SETUP: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        debug('ERROR S3_STORAGE_SETUP: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        debug('ERROR S3_STORAGE_SETUP: ' . $e->getMessage());
        }

    return false;
    }


/**
* Function to get the current S3 API description.
*
* @return array         SDK getApi() results; otherwise, FALSE.
*/
function s3_get_api()
    {
    global $lang;

    try
        {
        // Get the S3 configuration parameters and create a new S3 API client.
        $aws_sdk = s3_storage_setup();
        $s3Client = $aws_sdk->createS3();
        debug('S3_GET_API: S3 Client Setup Ok');

        // Use the client getApi to get the API description.
        $s3_result = $s3Client->getApi();
        $result['service_name'] = $s3_result->getServiceName();
        $result['service_fullname'] = $s3_result['metadata']['serviceFullName'];
        $result['serviceID'] = $s3_result->getServiceId();
        $result['api_version_date'] = $s3_result->getApiVersion();
        $result['api_version'] = $s3_result['metadata']['apiVersion'];
        $result['status'] = $lang['status-ok'];
        unset($s3Client);
        debug('S3_GET_API Results 2: ' . print_r($result, true));

        return $result;
        }
    catch(S3Exception $e)
        {
        debug('ERROR S3_GET_API: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        debug('ERROR S3_GET_API: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        debug('ERROR S3_GET_API: ' . $e->getMessage());
        }

    return false;
    }


/**
* Function to get the current S3 storage region.
*
* @return array         SDK getRegion() results; otherwise, FALSE.
*/
function s3_get_region()
    {
    global $lang;

    try
        {
        // Get the S3 configuration parameters and create a new S3 API client.
        $aws_sdk = s3_storage_setup();
        $s3Client = $aws_sdk->createS3();
        debug('S3_GET_REGION: S3 Client Setup Ok');

        // Use the client getRegion to get the region currently connected to.
        $result = $s3Client->getRegion();
        debug('S3_GET_REGION Results: ' . print_r($result, true));
        unset($s3Client);

        return $result;
        }
    catch(S3Exception $e)
        {
        debug('ERROR S3_GET_REGION: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        debug('ERROR S3_GET_REGION: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        debug('ERROR S3_GET_REGION: ' . $e->getMessage());
        }

    return false;
    }


/**
* Function to get the S3 endpoint that the SDK is currently connected to.
*
* @return array         SDK getEndpoint() results; otherwise, FALSE.
*/
function s3_get_endpoint()
    {
    global $lang;

    try
        {
        // Get the S3 configuration parameters and create a new S3 API client.
        $aws_sdk = s3_storage_setup();
        $s3Client = $aws_sdk->createS3();
        debug('S3_GET_ENDPOINT: S3 Client Setup Ok');

        // Use the client getEndpoint to get the endpoint currently connected to.
        $result = $s3Client->getEndpoint();
        $result1['scheme'] = $result->getScheme();
        $result1['endpoint'] = $result->getHost();
        unset($s3Client);
        debug('S3_GET_ENDPOINT Result: ' . print_r($result, true));

        if($result != '' && !stristr($result1['endpoint'], '..'))
            {
            $result1['status'] = true;
            }
        else
            {
            $result1['status'] = false;
            }

        return $result1;
        }
    catch(S3Exception $e)
        {
        debug('ERROR S3_GET_ENDPOINT: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        debug('ERROR S3_GET_ENDPOINT: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        debug('ERROR S3_GET_ENDPOINT: ' . $e->getMessage());
        }

    $result1['scheme'] = $lang['status-fail'];
    $result1['endpoint'] = $lang['status-fail'];
    $result1['status'] = $lang['status-fail'];
    return $result1;
    }


/**
* Function to define the available S3 storage classes and convert the S3 storage class code to a name.
*
* @param string  $s3_storage_class  S3 storage class code.
* @param boolean $format            Enable special display text format?
*
* @return array                     ('code' => 'value', 'name' => 'value', 'status' => value)
*/
function s3_storage_class($s3_storage_class, $format = false)
    {
    global $lang, $s3_storage_provider;
    $result['status'] = $lang['status-ok'];

    // Determine the storage class if different than AWS S3 usage (add other providers as needed).
    switch ($s3_storage_provider)
        {
        case 'AWS':
            $storage_class = $s3_storage_class;
            break;
        case 'DigitalOcean':
            $storage_class = 'STANDARD';
            break;
        default:
            $storage_class = 'OTHER';
        }

    // Determine the S3 storage class code and name.
    switch ($storage_class)
        {
        case 'STANDARD':
            $result['code'] = 'STANDARD';
            $result['name'] = 'Standard Storage';
            break;
        case 'INTELLIGENT_TIERING':
            $result['code'] = 'INTELLIGENT_TIERING';
            $result['name'] = 'Intelligent Tiering';
            break;
        case 'STANDARD_IA':
            $result['code'] = 'STANDARD_IA';
            $result['name'] = 'Standard, Infrequent Access Storage';
            break;
        case 'ONEZONE_IA':
            $result['code'] = 'ONEZONE_IA';
            $result['name'] = 'One Zone, Infrequent Access Storage';
            break;
        case 'REDUCED_REDUNDANCY':
            $result['code'] = 'REDUCED_REDUNDANCY';
            $result['name'] = 'Reduced Redundancy Storage';
            break;
        case 'OUTPOSTS':
            $result['code'] = 'OUTPOSTS';
            $result['name'] = 'Outposts';
            break;
        case 'OTHER':
            $result['code'] = 'default';
            $result['name'] = 'No Storage Type Used';
        default:
            $result['code'] = 'AllStorageTypes';
            $result['name'] = 'All Storage Types';
            $result['status'] = $lang['status-fail'];
        }

    if($format)
        {
        $result['name'] = " ({$result['name']})";
        }

    return $result;
    }


/**
* Function to get the owner of a specific S3 bucket.
*
* @param string  $s3_storage_bucket  S3 bucket name.
*
* @return array                      ('name' => value, 'id' => value, 'status' => value); otherwise, FALSE.
*/
function s3_bucket_owner($s3_storage_bucket)
    {
    global $lang;

    $s3_result['name'] = '';
    $s3_result['id'] = '';
    $s3_result['status'] = $lang['status-fail'];

    try
        {
        // Get the S3 configuration parameters and create a new S3 API client.
        $aws_sdk = s3_storage_setup();
        $s3Client = $aws_sdk->createS3();
        debug('S3_BUCKET_OWNER: S3 Client Setup Ok');

        // Use the client getBucketAcl to get the owner of the specified S3 bucket.
        $result = $s3Client->getBucketAcl([
           'Bucket' => $s3_storage_bucket,
        ]);

        unset($s3Client);
        if(!empty($result['Owner']['DisplayName']) && !empty($result['Owner']['ID']))
            {
            $s3_result['name'] = $result['Owner']['DisplayName'];
            $s3_result['id'] = $result['Owner']['ID'];
            $s3_result['status'] = $lang['status-ok'];
            }

        return $s3_result;
        }
    catch(S3Exception $e)
        {
        debug('ERROR S3_BUCKET_OWNER: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        debug('ERROR S3_BUCKET_OWNER: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        debug('ERROR S3_BUCKET_OWNER: ' . $e->getMessage());
        }

    return false;
    }


/**
* Function to check if a specific S3 bucket exists.
*
* @param string $s3_storage_bucket S3 bucket name.
*
* @return array                    SDK headBucket() results or FALSE.
*/
function s3_bucket_head($s3_storage_bucket)
    {
    try
        {
        // Get the S3 configuration parameters and create a new S3 API client.
        $aws_sdk = s3_storage_setup();
        $s3Client = $aws_sdk->createS3();
        debug('S3_BUCKET_HEAD: S3 Client Setup Ok');

        // Use the client headBucket to determine if the specified S3 bucket exists.
        $result = $s3Client->headBucket([
            'Bucket' => $s3_storage_bucket
            ]);
        unset($s3Client);
        debug('S3_BUCKET_HEAD Result: ' . print_r($result, true));

        return $result;
        }
    catch(S3Exception $e)
        {
        debug('ERROR S3_BUCKET_HEAD: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        debug('ERROR S3_BUCKET_HEAD: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        debug('ERROR S3_BUCKET_HEAD: ' . $e->getMessage());
        }

    return false;
    }


/**
* Function to get a the location (region) of a specific S3 bucket.
*
* @param string $s3_storage_bucket  S3 bucket name.
*
* @return array                     SDK getBucketLocation() results; otherwise, FALSE.
*/
function s3_bucket_location($s3_storage_bucket)
    {
    try
        {
        // Get the S3 configuration parameters and create a new S3 API client.
        $aws_sdk = s3_storage_setup();
        $s3Client = $aws_sdk->createS3();
        debug('S3_BUCKET_LOCATION: S3 Client Setup Ok');

        // Use the client getBucketLocation to determine the location of the specified S3 bucket.
        $result = $s3Client->getBucketLocation([
            'Bucket' => $s3_storage_bucket
            ]);
        debug('S3_BUCKET_LOCATION Results: ' . print_r($result, true));
        unset($s3Client);

        if(isset($result['LocationConstraint']))
            {
            $result['status'] = true;
            }
        else
            {
            $result['LocationConstraint'] = '';
            $result['status'] = false;
            }
        }
    catch(S3Exception $e)
        {
        $result['status'] = false;
        debug('ERROR S3_BUCKET_LOCATION: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        $result['status'] = false;
        debug('ERROR S3_BUCKET_LOCATION: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        $result['status'] = false;
        debug('ERROR S3_BUCKET_LOCATION: ' . $e->getMessage());
        }

    return $result;
    }


/**
* Function to list the available S3 buckets to the current owner and connection.
*
* @return array  SDK listBucket() results; otherwise, FALSE.
*/
function s3_bucket_list()
    {
    try
        {
        // Get the S3 configuration parameters and create a new S3 API client.
        $aws_sdk = s3_storage_setup();
        $s3Client = $aws_sdk->createS3();
        debug('S3_BUCKET_LIST: S3 Client Setup Ok');

        // Use the client listBuckets to list the buckets owned by the owner.
        $result = $s3Client->listBuckets([]);
        unset($s3Client);
        debug('S3_BUCKET_LIST Result: ' . print_r($result, true));

        return $result;
        }
    catch(S3Exception $e)
        {
        debug('ERROR S3_BUCKET_LIST: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        debug('ERROR S3_BUCKET_LIST: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        debug('ERROR S3_BUCKET_LIST: ' . $e->getMessage());
        }

    return false;
    }


/**
* Function to create an S3 object path from a normal filestore path.
*
* @param string  $path            A normal filestore path to a resource.
* @param boolean $trailing_slash  Add a trailing slash to the S3 object path?
*
* @return string                  S3 object path; otherweise, FALSE.
*/
function s3_object_path($path, $trailing_slash = false)
    {
    global $storagedir;

    try
        {
        // Add trailing slash to path if needed.
        $slash = '';
        if($trailing_slash)
            {
            $slash = DIRECTORY_SEPARATOR;
            }

        // Strip the $storagedir and leading slash from path to match S3 bucket path.
        $s3_path = ltrim(str_replace($storagedir, '', $path), DIRECTORY_SEPARATOR) . $slash;
        debug("S3 OBJECT PATH: {$s3_path}");

        return $s3_path;
        }
    catch(Exception $e)
        {
        debug('ERROR S3 OBJECT PATH: ' . $e->getMessage());
        }

    return false;
    }


/**
* Function to check if an object exists in a specified S3 bucket.
*
* @param string $s3_object  S3 object path.
*
* @return boolean           TRUE if the object exists in the S3 bucket; otherwise, FALSE.
*/
function s3_object_exists($s3_object)
    {
    global $lang, $s3_storage_bucket;

    try
        {
        // Get the S3 configuration parameters and create a new S3 API client.
        $aws_sdk = s3_storage_setup();
        $s3Client = $aws_sdk->createS3();
        debug('S3_OBJECT_EXISTS: S3 Client Setup Ok');

        // Use the client doesObjectExist to check if an object exists in the specified S3 bucket.
        $result = $s3Client->doesObjectExist($s3_storage_bucket, $s3_object);
        unset($s3Client);
        if($result)
            {
            debug("S3_OBJECT_EXISTS: Yes, {$s3_object}");
            return true;
            }
        else
            {
            debug("WARNING S3_OBJECT_EXISTS: No, {$s3_object}");
            }
        }
    catch(S3Exception $e)
        {
        debug('ERROR S3_OBJECT_EXISTS: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        debug('ERROR S3_OBJECT_EXISTS: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        debug('ERROR S3_OBJECT_EXISTS: ' . $e->getMessage());
        }

    return false;
    }


/**
* Function to get the metadata on a S3 object (S3 metadata, not the ResourceSpace metadata).
*
* @param string $s3_object  S3 object path.
*
* @return array             SDK headObject() results; otherwise, FALSE.
*/
function s3_object_head($s3_object)
    {
    try
        {
        global $lang, $s3_storage_bucket;

        // Get the S3 configuration parameters and create a new S3 API client.
        $aws_sdk = s3_storage_setup();
        $s3Client = $aws_sdk->createS3();
        debug('S3_OBJECT_HEAD: S3 Client Setup Ok');

        // Use the client headObject to get metadata on the specified S3 bucket.
        $result = $s3Client->headObject([
            'Bucket' => $s3_storage_bucket,
            'Key' => $s3_object
            ]);
        unset($s3Client);
        debug('S3_OBJECT_HEAD Result: ' . print_r($result, true));
        debug('S3_OBJECT_HEAD Result 2: ' . json_encode($result->toArray(), JSON_PRETTY_PRINT));
        debug("S3_OBJECT_HEAD Result 3: {$result['ContentLength']}");

        return $result;
        }
    catch(S3Exception $e)
        {
        debug('ERROR S3_OBJECT_HEAD: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        debug('ERROR S3_OBJECT_HEAD: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        debug('ERROR S3_OBJECT_HEAD: ' . $e->getMessage());
        }

    return false;
    }


/**
* Function to list specific objects in a S3 bucket using a prefix.
*
* @param string $s3_object_prefix  S3 object prefix to search on.
*
* @return array                    SDK listObjectsV2() results; otherwise, FALSE.
*/
function s3_object_list($s3_object_prefix)
    {
    global $lang, $s3_storage_bucket;

    try
        {
        // Get the S3 configuration parameters and create a new S3 API client.
        $aws_sdk = s3_storage_setup();
        $s3Client = $aws_sdk->createS3();
        debug('S3_OBJECT_LIST: S3 Client Setup Ok');

        // Use the client listObjectsV2 to list objects matching the prefix in the specified S3 bucket.
        $result = $s3Client->listObjectsV2([
            'Bucket' => $s3_storage_bucket,
            'Prefix' => $s3_object_prefix
            ]);
        unset($s3Client);
        debug('S3_OBJECT_LIST Results: ' . print_r($result, true));

        return $result;
        }
    catch(S3Exception $e)
        {
        debug('ERROR S3_OBJECT_LIST: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        debug('ERROR S3_OBJECT_LIST: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        debug('ERROR S3_OBJECT_LIST: ' . $e->getMessage());
        }

    return false;
    }


/**
* Function to upload a local file to a specified S3 bucket.
*
* @param string  $fs_path           Local resource filestore path.
* @param string  $s3_object         S3 object path.
* @param string  $s3_storage_class  S3 storage class code.
*
* @return array                     SDK ObjectUploader() or MultipartUploader results; otherwise, FALSE.
*/
function s3_object_upload($fs_path, $s3_object)
    {
    global $lang, $s3_storage_bucket, $s3_storage_class, $s3_storage_mpupload_gc;

    try
        {
        // Get the S3 configuration parameters and create a new S3 API client.
        $aws_sdk = s3_storage_setup();
        $s3Client = $aws_sdk->createS3();
        debug('S3_OBJECT_UPLOAD: S3 Client Setup Ok');

        // Using stream instead of file path, set options, and create an ObjectUploader.
        $source = fopen($fs_path, 'rb');
        $options = array('params' => array(
            'StorageClass' => $s3_storage_class
            ));
        $uploader = new ObjectUploader($s3Client, $s3_storage_bucket, $s3_object, $source, $acl = 'private', $options);
        debug('S3_OBJECT_UPLOAD: ObjectUploader Setup Ok');

        do
            {
            // Use the API upload.
            try {
                $result = $uploader->upload();
                if ($result['@metadata']['statusCode'] == '200')
                    {
                    debug("S3_OBJECT_UPLOAD: Ok, {$result['ObjectURL']}");
                    }
                else
                    {
                    debug('ERROR S3_OBJECT_UPLOAD: ' . print_r($result, true));
                    }
                }
            // Otherwise, use the API MultipartUpload for larger files.
            catch (MultipartUploadException $e)
                {
                rewind($source);
                $uploader = new MultipartUploader($s3Client, $source, [
                    'state' => $e->getState(),
                    'before_upload' => function(\Aws\Command $command)
                        {
                        // Run the PHP garbage collector before a S3 multipart upload to free memory for large uploads.
                        if($s3_storage_mpupload_gc)
                            {
                            $gc = gc_collect_cycles();
                            debug("S3_OBJECT_UPLOAD PHP Garbage Collector Cycles: {$gc}");
                            }
                        }
                    ]);
                if ($uploader['@metadata']['statusCode'] == '200')
                    {
                    debug("S3_OBJECT_UPLOAD: Ok, {$uploader['ObjectURL']}");
                    }
                else
                    {
                    debug('ERROR S3_OBJECT_UPLOAD MP: ' . print_r($uploader, true));
                    }
                }
            }
        while (!isset($result));

        unset($s3Client);
        return $result;
        }
    catch(S3Exception $e)
        {
        debug('ERROR S3_OBJECT_UPLOAD: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        debug('ERROR S3_OBJECT_UPLOAD: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        debug('ERROR S3_OBJECT_UPLOAD: ' . $e->getMessage());
        }

    return false;
    }


/**
* Function to download an object from a S3 bucket to a local file.
*
* @param string $s3_object  S3 object path.
* @param string $fs_file    Local filestore path.
*
* @return array             SDK getObject() results; otherwise, FALSE.
*/
function s3_object_download($s3_object, $fs_file)
    {
    global $s3_storage_bucket;

    try
        {
        // Get the S3 configuration parameters and create a new S3 API client.
        $aws_sdk = s3_storage_setup();
        $s3Client = $aws_sdk->createS3();
        debug('S3_OBJECT_DOWNLOAD: S3 Client Setup Ok');

        // Use the client getObject to download an object from a specified S3 bucket.
        $result = $s3Client->getObject([
            'Bucket' => $s3_storage_bucket,
            'Key' => $s3_object,
            'SaveAs' => $fs_file
            ]);
        unset($s3Client);
        debug("S3_OBJECT_DOWNLOAD From: {$s3_object}, Results: " . print_r($result, true));

        return $result;
        }
    catch(S3Exception $e)
        {
        debug('ERROR S3_OBJECT_DOWNLOAD: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        debug('ERROR S3_OBJECT_DOWNLOAD: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        debug('ERROR S3_OBJECT_DOWNLOAD: ' . $e->getMessage());
        }

    return false;
    }


/**
* Function to delete an object in a S3 bucket.
*
* @param string $s3_object  S3 object path.
*
* @return boolean           TRUE on success; otherwise, FALSE.
*/
function s3_object_delete($s3_object)
    {
    global $lang, $s3_storage_bucket;

    try
        {
        // Get the S3 configuration parameters and create a new S3 API client.
        $aws_sdk = s3_storage_setup();
        $s3Client = $aws_sdk->createS3();
        debug('S3_OBJECT_DELETE: S3 Client Setup Ok');

        // Use the client deleteObject to delete an object from the specified S3 bucket.
        $result = $s3Client->deleteObject([
            'Bucket' => $s3_storage_bucket,
            'Key' => $s3_object
            ]);
        unset($s3Client);

        $status_code = html_status_code($result['@metadata']['statusCode'], true);
        debug("S3_OBJECT_DELETE From: {$s3_object} with Status Code: {$status_code['text']}");
        if($status_code['success'])
            {
            return true;
            }
        }
    catch(S3Exception $e)
        {
        debug('ERROR S3_OBJECT_DELETE: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        debug('ERROR S3_OBJECT_DELETE: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        debug('ERROR S3_OBJECT_DELETE: ' . $e->getMessage());
        }

    return false;
    }


/**
* Function to copy an existing S3 object within a S3 bucket; used mainly to rename objects.
*
* @param string $object_from      S3 object path to copy from.
* @param string $object_to        S3 object path to copy to.
* @param string $s3_storage_class S3 storage class code.
*
* @return array                   SDK copyObject() results; otherwise, FALSE.
*/
function s3_object_copy($object_from, $object_to, $s3_storage_class)
    {
    global $lang, $s3_storage_bucket;
    debug("S3_OBJECT_COPY Input: From {$object_from} To {$object_to} in {$s3_storage_class} storage class");

    try
        {
        // Get the S3 configuration parameters and create a new S3 API client.
        $aws_sdk = s3_storage_setup();
        $s3Client = $aws_sdk->createS3();
        debug('S3_OBJECT_COPY: S3 Client Setup Ok');

        // Get the existing object size and storage class.
        $result = s3_object_head($sdk, $object_from);
        $size = (int)$result['ContentLength'];
        $size = (int)$result->search('ContentLength');
        if($size = '' || !$size)
            {
            $size = 0;
            }

        $from_strclass = " ({$result['StorageClass']})";
        $to_strclass = s3_storage_class($s3_storage_class, true);
        debug("S3_OBJECT_COPY From: {$object_from}{$from_strclass} To: {$object_to}{$to_strclass}, Filesize: " . formatfilesize($size));

        // If filesize <5GB, use the client copyObject.
        if($size > 5000000000 || $size == '')
            {
            $result = $s3Client->copyObject([
                'Bucket' => $s3_storage_bucket,
                'CopySource' => $object_from,
                'Key' => $object_to,
                'StorageClass' => $s3_storage_class
                ]);
            debug("S3_OBJECT_COPY From: {$object_from} To: {$object_to}, Results: " . print_r($result, true));
            unset($s3Client);

            return $result;
            }
        // If the filesize >5GB, use the API MultipartCopy.
        elseif($size >=5000000000)
            {
            $copier = new MultipartCopy($s3Client, $object_from, [
                'bucket' => $s3_storage_bucket,
                'key' => $object_to,
            ]);

            try
                {
                $result = $copier->copy();
                debug("S3_OBJECT_COPY Multipart Complete: {$result['ObjectURL']}");
                unset($s3Client);

                return $result;
                }
            catch (MultipartUploadException $e)
                {
                debug('ERROR S3_OBJECT_COPY Multipart: ' . $e->getMessage());
                }
            }
        }
    catch(S3Exception $e)
        {
        debug('ERROR S3_OBJECT_COPY: ' . $e->getMessage());
        }
    catch(AwsException $e)
        {
        debug('ERROR S3_OBJECT_COPY: RequestID ' . $e->getAwsRequestID() . ', Type ' . $e->getAwsErrorType() . ', Code ' . $e->getAwsErrorCode());
        }
    catch(Exception $e)
        {
        debug('ERROR S3_OBJECT_COPY: ' . $e->getMessage());
        }

    return false;
    }


/**
* Function to delete a filestore original file and create a zero-byte placeholder file in its place.
*
* @param string $fs_path  Original resource filestore path.
*
* @return array           ('delete' => boolean, 'placeholder' => boolean); otherwise, FALSE.
*/
function s3_file_placeholder($fs_path)
    {
    if(is_file($fs_path))
        {
        // Delete the filestore original file, as it is now in S3 storage.
        $result['delete'] = unlink($fs_path);
        debug('S3 FILE PLACEHOLDER Original Delete: ' . boolean_convert($result['delete'], 'ok') . ', ' . $fs_path);

        // Create a zero-byte placeholder file in the filestore with the same path and name as the original file.
        $ph_path = fopen($fs_path, 'wb');
        $result['placeholder'] = fclose($ph_path);
        debug('S3 FILE PLACEHOLDER Original Placeholder: ' . boolean_convert($result['placeholder'], 'ok'));
        }
    else // Error, filestore original file is missing.
        {
        debug('ERROR S3 FILE PLACEHOLDER: Original Missing');
        return false;
        }

    return $result;
    }


/**
* Function to determine a local filestore temp filepath for a given filepath using a unique, random filename.
*
* @param string $path    Resource filestore temp filepath.
* @param string $uniqid  Unique ID.
*
* @return string         Local filestore temp filepath.
*/
function s3_file_tempname($path, $uniqid = '', $subfolder = '')
    {
    debug("S3_FILE_TEMPNAME Input Path: {$path}");
    $file_path_info = pathinfo($path);
    $filename = md5(mt_rand()) . "_{$file_path_info['basename']}";

    if($uniqid == '' && $subfolder == '')
        {
        $tmp_dir = s3_create_temp('', false);
        }
    elseif($uniqid == '' && $subfolder != '')
        {
        $tmp_dir = s3_create_temp($subfolder, false);
        }
    else
        {
        $tmp_dir = get_temp_dir(false, $uniqid);
        }

    $s3_tmpfile = $tmp_dir . DIRECTORY_SEPARATOR . $filename;
    debug("S3_FILE_TEMPNAME Local Temp Path: {$s3_tmpfile}");

    return $s3_tmpfile;
    }


/**
* Function to create a local temp S3 folder for S3 processing and the S3 script tool logs.
*
* @params $subfolder    Optional: subfolder name.
*
* @return string        Local filestore S3 temp folder path; otherwise, FALSE.
*/
function s3_create_temp($subfolder = '', $trailing_slash = true)
    {
    // Define an OS-independent S3 temporary folder in the ../filestore/tmp folder.
    $s3_temp_dir = rtrim(get_temp_dir(false) . DIRECTORY_SEPARATOR . 's3_temp' . DIRECTORY_SEPARATOR . $subfolder, " /\\");

    // Check if the local S3 file temporary folder exists, if not, create it.
    if(!is_dir($s3_temp_dir))
        {
        $result = mkdir($s3_temp_dir, 0777, true);
        $result1 = chmod($s3_temp_dir, 0777);
        debug("S3_CREATE_TEMP: Created at {$s3_temp_dir} (" . boolean_convert($result, 'ok') . '/' . boolean_convert($result1, 'ok') . ')');
        if($result)
            {
            $s3_temp = $s3_temp_dir . DIRECTORY_SEPARATOR;
            }
        else
            {
            debug("ERROR S3_CREATE_TEMP: Could not create {$s3_temp_dir}");
            return false;
            }
        }
    else
        {
        if($trailing_slash)
            {
            $s3_temp = $s3_temp_dir . DIRECTORY_SEPARATOR;
            }
        else
            {
            $s3_temp = $s3_temp_dir;
            }
        debug("S3_CREATE_TEMP: {$s3_temp}");
        }

    chmod($s3_temp_dir, 0777);
    return $s3_temp;
    }


/**
* Function to cleanup a folder by purging files, not subfolders, based on file age or the last access in minutes.
*
* @param string $folder    Folder to cleanup.
* @param number $min_age   Minimum age in minutes.
* @param string $time_type Options: change or access
* @param number $max_age   Maximum age in minutes.
*
* @return boolean          TRUE on success; otherwise, FALSE.
*/
function s3_folder_cleanup($folder = '', $min_age = 5, $time_type = 'change', $max_age = '')
    {
    global $s3_temp_purge;

    // Get the folder path to cleanup.
    if($folder = '')
        {
        $tmp_dir = get_temp_dir(false);
        $flag = '/tmp ';
        }
    else
        {
        $tmp_dir = $folder;
        $flag = "{$folder} ";
        }

    // Set the max file age to use.
    if($max_age = '' || !$max_age || !isset($max_age))
        {
        $age = $s3_temp_purge * 86400;
        }
    else
        {
        $age = $max_age;
        $flag = 'S3 Temp ';
        }

    // Set the minimum file age to protect other operations.
    if($age < $min_age * 60)
        {
        $age = $min_age * 60;
        }

    // Check the specified folder exists.
    if(is_dir($tmp_dir))
        {
        // Loop through the specified folder.
        $time_now = time();
        foreach(new FilesystemIterator($tmp_dir) as $file)
            {
            // If item is a sub-folder, skip and continue loop.
            if(is_dir($file))
                {
                continue;
                }

            // Using file change age.
            if($time_type = 'change')
                {
                $time1 = $time_now - $file->getCTime();
                }
            // Using file access age.
            elseif($time_type = 'access')
                {
                $time1 = $time_now - $file->getATime();
                }

            // Delete the file if the file age is greater than the maximum age parameter.
            if(is_file($file) && $age == 0 || $time1 >= $age)
                {
                $result = unlink($file->getRealPath());
                debug("S3_FOLDER_CLEANUP Result: {$flag}" . boolean_convert($result, 'ok'));
                }
            }

        return true;
        }

    debug("ERROR S3_FOLDER_CLEANUP: {$tmp_dir} folder does not exist.");
    return false;
    }


/**
* Function to check if a file exists in a local filestore temp folder.
*
* @param string $subfolder    Filestore temp subfolder path.
* @param string $search_file  Filename to search for.
*
* @return boolean             TRUE on success; otherwise, FALSE.
*/
function tmp_file_search($subfolder, $search_file)
    {
    $tmp_dir = get_temp_dir(false) . DIRECTORY_SEPARATOR . $subfolder;

    foreach(new FilesystemIterator($tmp_dir) as $file)
        {
        $filename = pathinfo($file, PATHINFO_FILENAME);

        if(is_dir($file))
            {
            continue;
            }
        if(is_file($file) && strpos($filename, $search_file) !== false)
            {
            $result = true;
            return $result;
            }
        }

    return false;
    }


/**
* Function to get the current AWS S3 CloudWatch metric statistics; only valid when using AWS S3 storage.
*
* @param string  $namespace   CloudWatch namespace.
* @param string  $metricname  CloudWatch metric name.
* @param string  $dimensions  CloudWatch dimensions, storage type and bucket name key-value pairs.
* @param double  $start_time  Metric start time, use PHP strtotime.
* @param double  $end_time    Metric end time, use PHP strtotime.
* @param integer $period      Period of the metric in seconds.
* @param array   $statistics  Stastistic name: average, etc.
* @param string  $unit        CloudWatch metric unit.
*
* @return array               SDK getMetricStatistics() results; otherwise, FALSE.
*/
function s3_metric_statistics($namespace, $metric_name, $dimensions, $start_time, $end_time, $period, $statistics, $unit)
    {
    global $s3_storage_provider;

    if($s3_storage_provider == 'AWS')
        {
        try {
            // Get the S3 configuration parameters and create a new S3 CloudWatch client.
            $aws_sdk = s3_storage_setup();
            $cwClient = $aws_sdk->createCloudWatch();
            debug('S3_METRIC_STATISTICS: CloudWatch Client Setup Ok');

            // Get the specified metric statistics.
            $result = $cwClient->getMetricStatistics([
                'Namespace' => $namespace,
                'MetricName' => $metric_name,
                'Dimensions' => $dimensions,
                'StartTime' => $start_time,
                'EndTime' => $end_time,
                'Period' => $period,
                'Statistics' => $statistics,
                'Unit' => $unit
            ]);
            debug("S3_METRIC_STATISTICS {$metric_name} Result: " . print_r($result, true));

            if($result['@metadata']['statusCode'] != 200)
                {
                debug("WARNING S3_METRIC_STATISTICS: No datapoints found {$metric_name}");
                $result['error'] = "No datapoints found for {$metric_name}";
                $result['status'] = false;
                return $result;
                }

            return $result;
            }
        catch(AwsException $e)
            {
            debug('ERROR S3_METRIC_STATISTICS: ' . $e->getAwsErrorMessage());
            }
        catch(Exception $e)
            {
            debug('ERROR S3_METRIC_STATISTICS: ' . $e->getMessage());
            }
        }

    debug('ERROR S3_METRIC_STATISTICS: Only valid for AWS.');
    return false;
    }


/**
* Function to create the input dimension parameters for the AWS CloudWatch metric statistics.
*
* @param string $name1   Input dimension 1.
* @param string $value1  Input value 1.
* @param string $name2   Input dimension 2.
* @param string $value2  Input value 2.
*
* @return array          Array of key-value dimension pairs.
*/
function cw_dimension($name1, $value1, $name2, $value2)
    {
    global $s3_bucket;

    $dimensions = [
        [
        'Name' => $name1,
        'Value'=> $value1
        ],
        [
        'Name' => $name2,
        'Value' => $value2
        ]
    ];

    return $dimensions;
    }


/**
* Function to determine the total number and size of all files in a folder, not including subfolders.
*
* @param string  $folder  Filestore folder.
* @param boolean $string  Use human-readble text output?
*
* @return array           ('size' => value, 'number' => value)
*/
function folder_file_size($folder, $string = false)
    {
    // Set counters to zero and check if the specified folder is actually a folder.
    $result['size'] = 0;
    $result['number'] = 0;
    if(!is_dir($folder))
        {
        return false;
        }

    // Create an array of filenames within the specified folder, if none found, return zero.
    $files = scandir($folder);
    if(!$files)
        {
        if($string)
            {
            $result['size'] = formatfilesize($result['size']);
            }

        return $result;
        }
    $files = array_diff($files, array('.', '..'));

    // Loop through the folder files and cumulatively add up the file sizes.
    foreach ($files as $file)
        {
        if(is_file($folder . DIRECTORY_SEPARATOR . $file))
            {
            $result['size'] += filesize_unlimited($folder . DIRECTORY_SEPARATOR . $file);
            ++$result['number'];
            }
        }

    // If requested, convert the size in bytes, and return the folder info.
    unset($files);
    if($string)
        {
        $result['size'] = formatfilesize($result['size']);
        }

    debug('FOLDER_FILE_SIZE Result: ' . print_r($result, true));
    return $result;
    }


/** Function to convert HTML status codes.
*
* @param
*
* @return array
*/
function s3_check_resource_type($ref)
    {
    global $s3_storage_resource_types;

    // Get the resource type for the specified resource.
    $s3_res_type = sql_query("SELECT resource_type FROM resource WHERE ref='$ref'");
debug('RESOURCE_TYPES: ' . print_r($s3_res_type, true));

    }


/** Function to convert HTML status codes.
*
* @param integer   $code        HTML code.
* @param boolean   $show_text   Show text name for status code?
*
* @return array                 ('text' => value, 'error' => boolean, 'success' => boolean)
*/
function html_status_code($code, $show_text = false)
    {
    if(!is_numeric($code))
        {
        return false;
        }
    $code = (int)$code;
    $result['success'] = '';

    if($code >= 100 && $code <= 199)
        {
        $result['text'] = 'Informational Response';
        $result['error'] = false;
        }
    elseif($code >= 200 && $code <= 299)
        {
        $result['text'] = 'Success';
        $result['error'] = false;
        $result['success'] = true;
        }
    elseif($code >= 300 && $code <= 399)
        {
        $result['text'] = 'Redirection';
        $result['error'] = false;
        }
    elseif($code >= 400 && $code <= 499)
        {
        $result['text'] = 'Client Error';
        $result['error'] = true;
        }
    elseif($code >= 500 && $code <= 599)
        {
        $result['text'] = 'Server Error';
        $result['error']= true;
        }
    else
        {
        return false;
        }

    if($show_text)
        {
        $result['text'] = "{$code} ({$result['text']})";
        }

    return $result;
    }


/**
* Function to convert a boolean 'true-false' value to 'Ok-Fail' or 'Yes-No' text.
*
* @param boolean  $input  Boolean variable to convert.
* @param string   $type   Result formatting option: 'ok', 'yes', or 'true'
*
* @return string
*/
function boolean_convert($input, $type)
    {
    global $lang;

    if($input && $type == 'ok')
        {
        $result = $lang['status-ok'];
        }
    elseif(!$input && $type == 'ok')
        {
        $result = $lang['status-fail'];
        }
    elseif($input && $type == 'yes')
        {
        $result = $lang['yes'];
        }
    elseif(!$input && $type == 'yes')
        {
        $result = $lang['no'];
        }
    elseif($input && $type == 'true')
        {
        $result = $lang['false-true'][1];
        }
    elseif(!$input && $type == 'true')
        {
        $result = $lang['false-true'][0];
        }
    else // Insufficient input data.
        {
        $result = $lang['input_error'];
        }

    return $result;
    }
