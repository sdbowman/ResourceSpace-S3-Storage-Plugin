<?php
// s3_storage Plugin collection_download.php Hooks File
// This file adds hook functions to the ../pages/collection_download.php page.

include_once "../plugins/s3_storage/include/s3_storage_functions.php";


/**
* Hook to replace the Collection Download page title.
*
* @param
*
* @return
*/
function HookS3_storageCollection_downloadReplacecollectiondownloadtitle()
    {
    global $collection_download, $lang, $collectiondata;

    if($collection_download)
        {
        ?><h1><?php echo $lang['s3_storage_cdownload_title1'] . i18n_get_collection_name($collectiondata) . $lang['s3_storage_cdownload_title2']?></h1><?php
        return true;
        }

    return false;
    }


/**
* Hook to replace the Collection Download resource download loop.
*
* @param    array   $results            Array of search results.
* @param    array   $available_sizes    Array of available sizes for each resource.
* @param    array   $collection_data    Array of resource data.
*
* @return
*/
function HookS3_storageCollection_downloadreplacecollectiondownloadloop($results, $available_sizes, $collection_data)
    {
    global $collection_download;

    if($collection_download)
        {
        s3_zip_download($collection_data, $results, $available_sizes);
        return true;
        }

    return false;
    }


function HookS3_storageCollection_downloadReplaceprogress($uniqid, $userref, $result_count)
    {
    global $baseurl_short;

    echo "{$baseurl_short}plugins/s3_storage/pages/ajax/collection_download_progress.php?id=" . urlencode($uniqid) . '&user=' . urlencode($userref);
    }


/**
* Hook to add introductory text to the ../pages/collection_download.php page.
*
* @param
*
* @return
*/
function HookS3_storageCollection_downloadCollectiondownloadintro()
    {
    global $collection_download, $lang, $s3_zip_original;

    if($collection_download)
        {
        // Add the collection_download page intro text.
        if($s3_zip_original)
            {
            ?><p><?php echo $lang['s3_storage_cdownload_introtext2'];?></p><?php
            }
        else
            {
            ?><p><?php echo $lang['s3_storage_cdownload_introtext'];?></p><?php
            }

        return true;
        }

    return false;
    }


/**
* Hook to modify the download file formats on the ../pages/collection_download.php page.
*
* @param
*
* @return
*/
function HookS3_storageCollection_downloadCollectiondownloadfileformats()
    {
    global $collection_download, $lang;

    if($collection_download)
        {
        ?><option value="off"><?php echo $lang['s3_storage_cdownload_format'];?></option><?php

        return true;
        }

    return false;
    }


/**
* Hook to hide the download file format help text box on the ../pages/collection_download.php page.
*
* @param
*
* @return
*/
function HookS3_storageCollection_downloadCollectiondownloadformhelp()
    {
    global $collection_download;

    if($collection_download)
        {
        return true;
        }

    return false;
    }


/**
* Hook to check the Use Original if Selected Size is Unavailable by default.
*
* @return
*/
function HookS3_storageCollection_downloadReplaceuseoriginal()
    {
    global $collection_download, $lang, $count_data_only_types, $result_count, $s3_storage_original_default, $s3_zip_original;

    if($collection_download && !$s3_zip_original && $count_data_only_types !== $result_count)
        { ?>
        <div class="Question">
            <label for="use_original"><?php echo $lang['s3_storage_cdownload_original'];?> <br/><?php
            display_size_option('original', $lang['original'], false);
            if($s3_storage_original_default)
                {
                ?></label><input type=checkbox id="use_original" name="use_original" value="yes" checked><?php
                }
            else
                {
                ?></label><input type=checkbox id="use_original" name="use_original" value="yes"><?php
                }
        ?>
        <div class="clearerleft"> </div></div><?php
        return true;
        }

    return false;
    }


/**
* Hook to replace the collection download text file option.
*
* @return
*/
function HookS3_storageCollection_downloadCollectiondownloadtextfile()
    {
    global $collection_download, $lang, $zipped_collection_textfile_default_no;

    if($collection_download)
        { ?>
        <div class="Question">
            <label for="text"><?php echo $lang['s3_storage_cdownload_textfile'];?></label><?php
                if($zipped_collection_textfile_default_no)
                    { ?>
                    <input type="checkbox" id="text" name="text" value="true"><?php
                    }
                else
                    { ?>
                    <input type="checkbox" id="text" name="text" value="true" checked><?php
                    } ?>
            <div class="clearerleft"></div>
        </div><?php

        return true;
        }

    return false;
    }


/**
* Hook to include CSV metadata by default.
*
* @return
*/
function HookS3_storageCollection_downloadReplacecsvfile()
    {
    global $collection_download, $lang, $s3_storage_csv_default;

    if($collection_download)
        { ?>
        <!-- Add CSV file with the metadata of all the resources found in this colleciton -->
        <div class="Question">
            <label for="include_csv_file"><?php echo $lang['s3_storage_cdowbload_csvfile'];?></label><?php
            if($s3_storage_csv_default)
                { ?>
                <input type="checkbox" id="include_csv_file" name="include_csv_file" value="yes" checked><?php
                }
            else
                { ?>
                <input type="checkbox" id="include_csv_file" name="include_csv_file" value="yes"><?php
                }
            ?>
            <div class="clearerleft"></div>
        </div><?php

        return true;
        }

    return false;
    }
