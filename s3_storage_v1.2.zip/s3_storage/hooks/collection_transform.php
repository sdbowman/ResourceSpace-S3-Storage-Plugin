<?php
// Hooks file for the Transform plugin, collection_transform.php page.

function HookS3_storageCollection_transformCollection_transform_resource_path($resource, $path, $new_ext)
    {
    global $s3_storage_enable;

    // Download the file from S3 storage.
    if($s3_storage_enable)
        {
        try
            {
            // Determine the local S3 object tmpfile name.
            $fs_tmpfile = s3_file_tempname($path);
            $result['fs_tmpfile'] = $fs_tmpfile;

            // Determine the object path, check if it exists, and download the original file from a S3 bucket.
            $s3_object = s3_object_path($path, false);
            $s3_result = s3_object_exists($s3_object);
            if($s3_result)
                {
                s3_object_download($s3_object, $fs_tmpfile);
                }
            else
                {
                debug('ERROR TRANSFORM/COLLECION_DOWNLOAD_Resource_Path: S3 object Does Not Exist');
                }
            }
        catch(Exception $e)
            {
            debug('ERROR TRANSFORM/COLLECION_DOWNLOAD_Resource_Path S3: ' . $e->getMessage());
            }
        }

    if(is_readable($fs_tmpfile))
        {
        $result = $fs_tmpfile;
        }
    else
        {
        $result = '';
        }

    debug('TRANSFORM/COLLECION_DOWNLOAD_Resource_Path Result: ' . print_r($result, true));
    return $result;
    }


function HookS3_storageCollection_transformCollection_transform_end($path)
    {
    global $s3_storage_enable;

    if($s3_storage_enable)
        {
        // Determine the local S3 object tmpfile name.
        $fs_tmpfile = s3_file_tempname($path);

        // Delete the temporary original file.
        if(is_file($fs_tmpfile))
            {
            unlink($fs_tmpfile);
            debug("HookS3_storageCollection_transformCollection_transform_end: Deleting {$fs_tmpfile});
            }
        }
    }
