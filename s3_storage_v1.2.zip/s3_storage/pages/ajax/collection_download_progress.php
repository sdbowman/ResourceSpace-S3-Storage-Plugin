<?php
//include "../../../../include/db.php";

global $lang;

$content = '';
if($content == '')
    {
    echo ' ';
    }
elseif($content == 'zipping')
    {
    echo 'Processing ';
    }
else # Echo whatever the script has placed here.
    {
    ob_start();
    echo $content;
    ob_flush();
    exit();
    }
