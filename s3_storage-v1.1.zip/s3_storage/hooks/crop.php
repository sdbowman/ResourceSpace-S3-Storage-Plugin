<?php
// Hooks for Transform plugin, crop.php page.

// Download the S3 stored original file to the ../filestore/tmp folder.
function HookS3_storageCropTransformcropbeforegetsize($ref, $original_path, $original_extension, $saveaction)
    {
    global $s3_storage_enable;

    // Download the file from S3 storage.
    $fs_tmpfile = '';
    if($s3_storage_enable)
        {
        try
            {
            // Determine the local S3 object tmpfile name.
            $fs_tmpfile = rtrim(s3_file_tempname($original_path), DIRECTORY_SEPARATOR);

            // Determine the object path, check if it exists, and download the original file from a S3 bucket.
            $s3_object = s3_object_path($original_path, false);
            $s3_result = s3_object_exists($s3_object);
            if($s3_result)
                {
                s3_object_download($s3_object, $fs_tmpfile);
                }
            else
                {
                debug('ERROR TRANSFORM-CROP/Transformcropbeforegetsize: S3 object Does Not Exist');
                }
            }
        catch(Exception $e)
            {
            debug('ERROR TRANSFORM-CROP/Transformcropbeforegetsize S3: ' . $e->getMessage());
            }
        }

    if(is_readable($fs_tmpfile))
        {
        $result = $fs_tmpfile;
        }
    else
        {
        $result = '';
        }

    debug('TRANSFORM-CROP/Transformcropbeforegetsize Result: ' . print_r($result, true));
    return $fs_tmpfile;
    }


// Create the full, temp file path from the filename.
function HookS3_storageCropTransformcropbeforegetsize2($hookfile)
    {
    global $s3_storage_enable;

    if($s3_storage_enable && $hookfile != '')
        {
        // Get the S3_Storage plugin temp hookfile path.
        return s3_create_temp() . $hookfile;
        }
    else
        {
        return;
        }
    }


// Delete the temporary downloaded S3 original file.
function HookS3_storageCropAftercropfinish($s3_temp_path, $new_path)
    {
    global $s3_storage_enable;

    if($s3_storage_enable)
        {
        // Get the temp folder.
        $s3_temp_dir = s3_create_temp();

        // Create an array of the temp files to delete.
        $files[] = $s3_temp_path;
        //$files[] = $new_path;

        // Loop through the files and check if the input folder is in the ../filestore/tmp path; delete if in path.
        foreach($files as $file)
            {
            $temp_check = strpos($file, $s3_temp_dir);
            if($temp_check == 0 || $temp_check == 1 && is_file($file))
                {
                $result = unlink($file);
                debug("HOOKS3_storageCropTransform_crop_alternative Deleting Temp File: {$file} ({$result})");
                }
            else
                {
                debug("ERROR HOOKS3_storageCropTransform_crop_alternative: Could not delete temp file: {$file}");
                }
            }
        }

    return;
    }
